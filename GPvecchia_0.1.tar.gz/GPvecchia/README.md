# GPvecchia
Fast Gaussian-process inference using Vecchia approximations
